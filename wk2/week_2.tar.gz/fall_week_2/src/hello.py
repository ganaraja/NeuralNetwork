def main():
    print("Hello from intro-to-pytorch!")


if __name__ == "__main__":
    main()
