# Getting started with the labs

You will find the lab notes and other related documentation that will help you with your project.

## Config file paths
Update entries of the `config.yaml` file of the project's root folder to point to suitable paths in your local:
